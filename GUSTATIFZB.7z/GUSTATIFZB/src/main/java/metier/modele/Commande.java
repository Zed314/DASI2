/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metier.modele;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
/**
 *
 * @author hcburca
 */
@Entity
public class Commande implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long numeroDeCommande;
    private long dureeEstimee;
    private double total;
    
    @ManyToOne
    private Client client;
    @ManyToOne
    private Livreur livreur;
       
    @ManyToOne
    private Restaurant restaurant;
    
    @OneToMany
    private List<ProduitDeCommande> contenu;
    
    private String status;
    private Calendar dateCommande;
    private Calendar dateLivraison;

    public Commande(long dureeEstimee, double total)
    {
    
    }
    public Commande()
    {
    
    }

    public Client getClient() {
        return client;
    }

    public Livreur getLivreur() {
        return livreur;
    }

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public List<ProduitDeCommande> getContenu() {
        return contenu;
    }

    public String getStatus() {
        return status;
    }

    public Calendar getDateCommande() {
        return dateCommande;
    }

    public Calendar getDateLivraison() {
        return dateLivraison;
    }
    
    public long getNumeroDeCommande() {
        return numeroDeCommande;
    }

    public long getDureeEstimee() {
        return dureeEstimee;
    }

    public double getTotal() {
        return total;
    }
    
    public void setDureeEstimee(long dureeEstimee) {
        this.dureeEstimee = dureeEstimee;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public void setLivreur(Livreur livreur) {
        this.livreur = livreur;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    public void setContenu(List<ProduitDeCommande> contenu) {
        this.contenu = contenu;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setDateCommande(Calendar dateCommande) {
        this.dateCommande = dateCommande;
    }

    public void setDateLivraison(Calendar dateLivraison) {
        this.dateLivraison = dateLivraison;
    }
    
    

}
