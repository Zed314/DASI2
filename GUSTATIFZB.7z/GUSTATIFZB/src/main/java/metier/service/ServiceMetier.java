/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metier.service;

import dao.ClientDAO;
import dao.JpaUtil;
import dao.ProduitDAO;
import dao.RestaurantDAO;
import java.util.List;
import metier.modele.Client;
import metier.modele.Produit;
import metier.modele.Restaurant;

/**
 *
 * @author hcburca
 */
public class ServiceMetier {

    public ServiceMetier() {

    }

    public boolean enregistrerUnClient(Client c) {
        JpaUtil.init();
        JpaUtil.creerEntityManager();
        boolean check = true;
        ClientDAO cD = new ClientDAO();

        JpaUtil.ouvrirTransaction();
        try {
            cD.create(c);
        } catch (Exception e) {
            System.err.println(e);
            check = false;
        }
        JpaUtil.validerTransaction();

        JpaUtil.fermerEntityManager();
        JpaUtil.destroy();
        return check;
    }

    public List<Restaurant> listerLesRestaurants() {
        JpaUtil.init();
        JpaUtil.creerEntityManager();
        RestaurantDAO rD = new RestaurantDAO();
        List<Restaurant> listRes = null;
        try {
            listRes = rD.findAll();
        } catch (Exception e) {
            System.err.println(e);
        }
        JpaUtil.fermerEntityManager();
        JpaUtil.destroy();

        return listRes;
    }

    public Restaurant trouverRestaurantParId(long id) {
        JpaUtil.init();
        JpaUtil.creerEntityManager();
        
        RestaurantDAO rD = new RestaurantDAO();
        Restaurant res = null;
        try {
            res = rD.findById(id);
        } catch (Exception e) {
            System.err.println(e);
        }

        JpaUtil.fermerEntityManager();
        JpaUtil.destroy();

        return res;
    }

  /*  public List<Produit> listerLesProduitsDUnRestaurant(Restaurant r) {
        JpaUtil.init();
        JpaUtil.creerEntityManager();
        
        ProduitDAO pD = new ProduitDAO();
        List<Produit> prods = null;
        try {
            res = pD.findById(id);
        } catch (Exception e) {
            System.err.println(e);
        }
        
        JpaUtil.fermerEntityManager();
        JpaUtil.destroy();
    }*/
}
