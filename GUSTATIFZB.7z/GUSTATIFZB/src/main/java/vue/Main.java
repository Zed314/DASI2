/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

import dao.ClientDAO;
import dao.ProduitDAO;
import dao.RestaurantDAO;
import dao.JpaUtil;
import metier.modele.Client;
import metier.modele.Produit;
import metier.modele.Restaurant;
import metier.service.ServiceMetier;
/**
 *
 * @author hcburca
 */
public class Main {

    public static void main(String[] args) {
    /*    JpaUtil.init();
        JpaUtil.creerEntityManager();

        ClientDAO Cd = new ClientDAO();
        ProduitDAO pD = new ProduitDAO();
        RestaurantDAO rD = new RestaurantDAO();
       

        JpaUtil.ouvrirTransaction();
        try {          
            System.out.println(Cd.findAll());
            System.out.println(pD.findAll());
            System.out.println(rD.findAll());
        } catch (Exception e) {
            System.err.println(e);
        }
        JpaUtil.validerTransaction();

        JpaUtil.fermerEntityManager();
        JpaUtil.destroy();*/
        ServiceMetier sm = new ServiceMetier();
        System.out.println(sm.trouverRestaurantParId(2));
    }

}
